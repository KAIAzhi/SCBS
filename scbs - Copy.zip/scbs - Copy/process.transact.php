<?php

 require 'connection.php';
 $sql = "SELECT tr_date, COUNT(*) AS date_count
 FROM transaction
 GROUP BY tr_date
 ORDER BY tr_date";
$result = mysqli_query($conn, $sql);

// Arrays to hold the labels (dates) and counts
$dates = [];
$dateCounts = [];

while ($row = mysqli_fetch_assoc($result)) {
$dates[] = $row['tr_date'];
$dateCounts[] = $row['date_count'];
}


function getTransactionList($conn)
  {
    $sql = "SELECT * FROM transaction";
    $result = $conn->query($sql);
    if($result)
    {
      if($result->num_rows > 0)
      {
        while($row = $result->fetch_assoc())
        {
          $data[] = $row;
        }
      }
      else
      {
        $data = [];
      }      
    }
    else
    {
      $data = [];
      exit();//error
    }
    return $data;
  }



  function getTransactionItemList($conn)
  {
    $sql = "SELECT itemname, quantity, price FROM transactionitem WHERE tr_id = 1;";
    $result = $conn->query($sql);
    if($result)
    {
      if($result->num_rows > 0)
      {
        while($row = $result->fetch_assoc())
        {
          $data[] = $row;
        }
      }
      else
      {
        $data = [];
      }      
    }
    else
    {
      $data = [];
      exit();//error
    }
    return $data;
  }

?>