    <?php
    require ('thirdparty/fpdf.php');
	include 'connection.php';

	$sql = "SELECT * FROM transaction";
	$result = $conn->query($sql);

    //$content = $_POST ['content'];
    //$textareaContent = $_POST ['textareaContent'];
    $pdf = new FPDF();
    $pdf -> AddPage();
    $pdf -> SetFont ('Arial','',20);
    $pdf -> Image ('logo.png',10,10,50, -100);
    $pdf -> Cell (0,10, 'Transaction Report',0,1,'C');
    //$pdf -> Cell (0,10, $textareaContent,0,1,'C');
$pdf->Ln();
	if ($result->num_rows > 0) {
		$pdf->SetFont('Arial', 'B', 12);
    	$pdf->SetFillColor(200, 200, 200);
    // Table Header
    $pdf->Cell(30, 10, 'Transaction ID', 1, 0, 'C', true);
    $pdf->Cell(30, 10, 'Date', 1, 0, 'C', true);
    $pdf->Cell(30, 10, 'Store', 1, 0, 'C', true);
    $pdf->Cell(30, 10, 'Service', 1, 0, 'C', true);
    $pdf->Cell(25, 10, 'Discount', 1, 0, 'C', true);
    $pdf->Cell(25, 10, 'Amount', 1, 0, 'C', true);
    $pdf->Cell(20, 10, 'Total', 1, 1, 'C', true);
		$pdf->SetFont('Arial', '', 12);
    while ($row = $result->fetch_assoc()) {
        $pdf->Cell(30, 10, $row['tr_id'], 1);
        $pdf->Cell(30, 10, $row['tr_date'], 1);
        $pdf->Cell(30, 10, $row['store'], 1);
        $pdf->Cell(30, 10, $row['service'], 1);
		$pdf->Cell(25, 10, $row['discount'], 1);
		$pdf->Cell(25, 10, $row['tr_amount'], 1);
		$pdf->Cell(20, 10, $row['total'], 1);
        $pdf->Ln(); // Line break
    }
	} else {
    $pdf->Cell(0, 10, 'No data found', 0, 1, 'C');
	}

    $pdf->Output();
    ?>
