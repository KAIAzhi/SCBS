<?php 
session_start();

$verified = isset($_GET['verified']) ? $_GET['verified'] : '';
if (isset($_SESSION['admin_users'])) {
    header("Location:dashboard.php");
}
?>
<html>
<head>
    <title>Senior Citizen Booklet System</title>
    <style>
        body, html {
            height: 100%;
            margin: 0;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #f0f4f8;
        }
        .container {
            display: flex;
            align-items: center;
            justify-content: center;
            height: 100%;
        }
        .card {
            background-color: #c8d9e6;
            padding: 40px 60px;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
            width: 350px;
            display: flex;
            flex-direction: column;
        }
        h1 {
            text-align: left;
            margin-bottom: 10px;
            font-size: 2rem;
            font-weight: bold;
            color: #0a0a23;
        }
        p {
            text-align: center;
            margin-bottom: 20px;
            font-size: 1.2rem;
            font-weight: bold;
            color: #0a0a23;
        }
        label {
            font-size: 1rem;
            margin-bottom: 5px;
            color: #0a0a23;
        }
        input {
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #333;
            border-radius: 5px;
            width: 100%;
        }
        button {
            padding: 10px;
            background-color: #0a0a23;
            color: #fff;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 100%;
        }
        a {
            text-align: left;
            margin-top: 10px;
            color: #0a0a23;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="card">
            <form method="POST" action="login.process.php">
                <h1>Log In</h1>
                <p>Welcome To SCBS</p>
                <label>First Name:</label>
                <input type="text" id="username" placeholder="Sample" name="admin_users" required>

                <label>Password:</label>
                <input type="password" id="password" placeholder="Password" name="password" required>
                <button>Log in</button>

                <a href="#">Forgot Password?</a>
                <p>Need a SCBS account? <a href="#" id="myBtn">Create Account</a></p>
            </form>
        </div>
    </div>
</body>
</html>
