<?php
    include 'item.transact.php';
    $itemList = getItemList($conn);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SCBS Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/html5-qrcode/2.3.4/html5-qrcode.min.js" integrity="sha512-k/KAe4Yff9EUdYI5/IAHlwUswqeipP+Cp5qnrsUjTPCgl51La2/JhyyjNciztD7mWNKLSXci48m7cctATKfLlQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <style>
        /* bars */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        body {
            height: 100%;
        }
        .sidebar {
            width: 200px;
            background-color: #2C3E50;
            color: white;
            display: flex;
            flex-direction: column;
            text-align: center;
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            transition: width 0.3s ease;
        }
        .sidebar.shrink {
            width: 60px;
        }
        .sidebar h2 {
            padding: 15px;
            height: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .menu-item {
            padding: 15px;
            background-color: #D0DFE9;
            color: black;
            text-decoration: none;
            display: flex;
            align-items: center;
            border-bottom: 1px solid white;
            transition: padding 0.3s ease;
        }
        .menu-item i {
            margin-right: 10px;
        }
        .menu-item span {
            display: inline;
        }
        .sidebar.shrink .menu-item {
            text-align: center;
            
        }
        .sidebar.shrink .menu-item span {
            display: none;
        }
        .sidebar.shrink .menu-item i {
            display: block;

            font-size: 24px;
        }
        .menu-item:hover, .active {
            background-color: #5E7D8D;
            color: white;
        }
        .logout {
            margin-top: auto;
            background-color: #D0DFE9;
            text-align: center;
        }
        .main-content {
            flex-grow: 1;
            display: flex;
            flex-direction: column;
            margin-left: 200px; /* Adjust for the width of the sidebar */
            transition: margin-left 0.3s ease;
        }
        .main-content.shrink {
            margin-left: 60px;
        }
        .topbar {
            width: calc(100% - 200px); /* Adjust for the width of the sidebar */
            height: 50px;
            background-color: #2C3E50;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
            color: white;
            position: fixed;
            top: 0;
            left: 200px; /* Adjust for the width of the sidebar */
            z-index: 1000;
            transition: left 0.3s ease, width 0.3s ease;
        }
        .topbar.shrink {
            left: 60px;
            width: calc(100% - 60px);
        }
        .content {
            flex-grow: 1;
            background-color: white;
            padding: 20px;
            margin-top: 32px; /* Adjust for the height of the topbar */
            align-items: center;
            justify-content: center;
        }
        .user-icon {
            display: flex;
            align-items: center;
        }
        .user-icon span {
            margin-right: 10px;
        }
        .user-icon img {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background-color: #29A0B1;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .text-profile h1{
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 10px;
            border-bottom: 2px solid #2C3E50;
            padding-bottom: 5px;
        }
        .dashboard{
            display: flex;
            justify-content: center;
        }
        #reader {
            width: 700px;
            height: 220px;
        }
        #result {
            text-align: center;
            font-size: 1.5rem;
        }
        .table-container {
            margin-top: 30px;
            width: 100%;
        }
        .table {
            width: 100%;
            border-collapse: collapse;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .table th, .table td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
        }

        .table th {
            background-color: #5b2c6f;
            color: white;
        }

    </style>
    <script>
        function showTable(tab) {

            const tabs = document.querySelectorAll('.tab');
            tabs.forEach(t => t.classList.remove('active'));
            document.querySelector(`[data-tab="${tab}"]`).classList.add('active');
        }

        function toggleSidebar() {
            const sidebar = document.querySelector('.sidebar');
            const mainContent = document.querySelector('.main-content');
            const topbar = document.querySelector('.topbar');

            sidebar.classList.toggle('shrink');
            mainContent.classList.toggle('shrink');
            topbar.classList.toggle('shrink');
        }

    </script>
</head>
<body>
    <div class="sidebar">
        <h2>SCBS</h2>
        <a href="dashboard.php" class="menu-item"><i class="fas fa-tachometer-alt"></i> <span>DASHBOARD</span></a>
        <a href="transaction.php" class="menu-item"><i class="fas fa-exchange-alt"></i> <span>TRANSACTION</span></a>
        <a href="qrcam.php" class="menu-item active"><i class="fas fa-qrcode"></i> <span>SCAN QR</span></a>
		<a href="list.php" class="menu-item"><i class="fas fa-qrcode"></i> <span>CITIZEN LIST</span></a>
        <a href="index.php" class="menu-item logout"><i class="fas fa-sign-out-alt"></i> <span>LOG OUT</span></a>
    </div>
    <div class="main-content">
        <div class="topbar">
            <button onclick="toggleSidebar()">☰</button>
            <div class="user-icon">
                <span>Merchant Name</span>
                <img src="https://via.placeholder.com/30" alt="User Icon">
            </div>
        </div>

         <div class="content">
            <div class="text-profile">
                <h1>SCAN QR</h1>
            </div>

            <div class="dashboard">
                <div id="reader"></div>
            </div>

            <div id="result"></div>

            <div id="medicine-table" class="data-table table-container">
                <table class="table">
                    <thead>
                        <tr>
                            <th>Transaction ID</th>
                            <th>Date & Time</th>
                            <th>Item/Service</th>
                            <th>Amount</th>
                            <th>Discount</th>
                            <th>Total Payable</th>
                        </tr>
                    </thead>
                    <tbody>
                            <tr>
                            <?php
                            foreach ($itemList as $items) {
                            ?>
                            <tr id="myBtn">
                                <td><?php echo $items['item_id']; ?></td>
                                <td><?php echo $items['merchant_id']; ?></td>
                                <td><?php echo $items['item_name']; ?></td>
                                <td><?php echo $items['current_price']; ?></td>
                                <td><?php echo $items['description']; ?></td>
                                <td><?php echo $items['date_added']; ?></td>
                            </tr>
                        <?php
                            }
                        ?>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div> <!-- .content -->
    </div> <!-- .main-content -->
</body>
<script>

     const scanner = new Html5QrcodeScanner('reader', { 
        // Scanner will be initialized in DOM inside element with id of 'reader'
        qrbox: {
            width: 250,
            height: 250,
        },  // Sets dimensions of scanning box (set relative to reader element width)
        fps: 20, // Frames per second to attempt a scan
    });


    scanner.render(success, error);
    // Starts scanner

    function success(result) {

        document.getElementById('result').innerHTML = `
        <h2>Success!</h2>
        <p>${result}</p>
        `;
        // Prints result as a link inside result element

        scanner.clear();
        // Clears scanning instance

        document.getElementById('reader').remove();
        // Removes reader element from DOM since no longer needed
    
    }

    function error(err) {
        console.error(err);
        // Prints any errors to the console
    }
</script>

</html>
