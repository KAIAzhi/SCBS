<?php 
 session_start();
 require 'connection.php';
  
 $admin    = $_POST    ['admin_users'];
 $password = $_POST    ['password'];
 
 $sql = "SELECT * FROM admin_user WHERE admin_users = '$admin' AND password = '$password'";


 $result = $conn->query($sql);

 if($result)
 { 
    if($result->num_rows == 0)//empty
    {
        header("Location: index.php?verified=false");
    }
    else//result ok
    { 
         while($row = $result->fetch_assoc())
         {
          $_SESSION['admin_users'] = $row['admin_users'];
           header("Location: dashboard.php");
         }
    }
 }
?>