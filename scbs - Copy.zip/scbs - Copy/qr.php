<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SCBS Dashboard</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        body {
            display: flex;
            height: 100vh;
        }
        .sidebar {
            width: 200px;
            background-color: #2C3E50;
            color: white;
            display: flex;
            flex-direction: column;
            text-align: center;
        }
        .sidebar h2 {
            padding: 15px;
            height: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .menu-item {
            padding: 15px;
            background-color: #D0DFE9;
            color: black;
            text-decoration: none;
            display: block;
            border-bottom: 1px solid white;
        }
        .menu-item:hover, .active {
            background-color: #5E7D8D;
            color: white;
        }
        .logout {
            margin-top: auto;
            background-color: #D0DFE9;
            text-align: center;
        }
        .main-content {
            flex-grow: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
        }
        .topbar {
            width: 100%;
            height: 60px;
            background-color: #2C3E50;
            display: flex;
            justify-content: flex-end;
            align-items: center;
            padding: 0 20px;
            color: white;
        }
        .content {
            flex-grow: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }
        .user-icon {
            display: flex;
            align-items: center;
        }
        .user-icon span {
            margin-right: 10px;
        }
        .user-icon img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background-color: #29A0B1;
        }
        .card {
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 20px;
            border-radius: 10px;
            width: 350px;
            background-color: #fff;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        .qr img {
            width: 150px;
            height: auto;
            margin-bottom: 20px;
        }
        .text {
            font-size: 1rem;
            color: #333;
        }
        .name {
            font-size: 1.4rem;
            font-weight: bold;
            margin-bottom: 10px;
        }
        .mobile, .id-number {
            font-size: 1.1rem;
            margin-bottom: 5px;
        }
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>SCBS</h2>
        <a href="dashboard.php" class="menu-item">DASHBOARD</a>
        <a href="transaction.php" class="menu-item">TRANSACTION</a>
        <a href="qr.php" class="menu-item">QR SCAN</a>
        <a href="profile.php" class="menu-item">PROFILE</a>
        <a href="#" class="menu-item">ABOUT</a>
        <a href="#" class="menu-item logout">LOG OUT</a>
    </div>
    <div class="main-content">
        <div class="topbar">
            <div class="user-icon">
                <span>Senior Citizen Name</span>
                <img src="https://via.placeholder.com/30" alt="User Icon">
            </div>
        </div>
        <div class="content">
            <div class="card">
                <div class="qr">
                    <img src="qrimage.png" alt="QR Code">
                </div>
                <div class="text">
                    <p class="name">Jzhi Garces</p>
                    <p class="mobile">Mobile Number: 09123452345</p>
                    <p class="id-number">ID Number: 049-241-234</p>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
