<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SCBS Dashboard</title>
    <style>
        /* bars */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        body {
            display: flex;
            height: 100vh;
        }
        .sidebar {
            width: 200px;
            background-color: #2C3E50;
            color: white;
            display: flex;
            flex-direction: column;
            text-align: center;
        }
        .sidebar h2 {
            padding: 15px;
            height: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .menu-item {
            padding: 15px;
            background-color: #D0DFE9;
            color: black;
            text-decoration: none;
            display: block;
            border-bottom: 1px solid white;
        }
        .menu-item:hover, .active {
            background-color: #5E7D8D;
            color: white;
        }
        .logout {
            margin-top: auto;
            background-color: #D0DFE9;
            text-align: center;
        }
        .main-content {
            flex-grow: 1;
            display: flex;
            flex-direction: column;
        }
        .topbar {
            width: 100%;
            height: 50px;
            background-color: #2C3E50;
            display: flex;
            justify-content: flex-end;
            align-items: center;
            padding: 0 20px;
            color: white;
        }
        .content {
            flex-grow: 1;
            background-color: white;
            padding: 20px;
        }
        .user-icon {
            display: flex;
            align-items: center;
        }
        .user-icon span {
            margin-right: 10px;
        }
        .user-icon img {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background-color: #29A0B1;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        /* bars */
    </style>
</head>
<body>
    <div class="sidebar">
        <h2>SCBS</h2>
        <a href="#" class="menu-item active">DASHBOARD</a>
        <a href="#" class="menu-item">TRANSACTION</a>
        <a href="#" class="menu-item">QR SCAN</a>
        <a href="profile.php" class="menu-item">PROFILE</a>
        <a href="#" class="menu-item ">ABOUT</a>
        <a href="#" class="menu-item logout">LOG OUT</a>
    </div>
    <div class="main-content">
        <div class="topbar">
            <div class="user-icon">
                <span>Senior Citizen Name</span>
                <img src="https://via.placeholder.com/30" alt="User Icon">
            </div>
        </div>
        <div class="content">
            <!-- Main content goes here -->
            

        </div>
    </div>
</body>
</html>
