<?php 
 session_start();
 require 'connection.php';
 function getAge($date)
  {
  //date in mm/dd/yyyy format; or it can be in other formats as well
  $birthDate = $date;
  //explode the date to get month, day and year
  $birthDate = explode("-", $birthDate);
  //get age from date or birthdate
  $age = (date("md", date("U", mktime(0, 0, 0, $birthDate[2], $birthDate[1], $birthDate[0]))) > date("md")
    ? ((date("Y") - $birthDate[0]) )
    : (date("Y") - $birthDate[0]));
   return $age;
  }
 $fname    = $_POST    ['first_name'];
 $password = $_POST    ['password'];
 
 $sql = "SELECT * FROM registration_info WHERE first_name = '$fname' AND password = '$password'";


 $result = $conn->query($sql);

 if($result)
 { 
    if($result->num_rows == 0)//empty
    {
        header("Location: index.php?verified=false");
    }
    else//result ok
    { 
		
		
         while($row = $result->fetch_assoc())
         {
          $_SESSION['first_name'] = $row['first_name'];
          $_SESSION['last_name'] = $row['last_name'];
          $_SESSION['contact'] = $row['contact'];
          $_SESSION['birthday'] = $row['birthday'];
          $_SESSION['address'] = $row['address'];
          $_SESSION['email'] = $row['email'];
          $_SESSION['senior_id'] = $row['senior_id'];
          $_SESSION['age'] = getAge($_SESSION['birthday']);
           header("Location: dashboard.php");
         }
		
    }
 }
?>