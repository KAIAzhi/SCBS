<?php
session_start();
if (!isset($_SESSION['first_name'])) {
    header("Location: index.php");
}
?>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SCBS Profile</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <link rel="stylesheet" href="styles.css">
    
    <style>
        /* bars */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        body {
            display: flex;
            height: 100%;
        }
        .sidebar {
            width: 200px;
            background-color: #2C3E50;
            color: white;
            display: flex;
            flex-direction: column;
            text-align: center;
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            transition: width 0.3s ease;
        }
        .sidebar.shrink {
            width: 60px;
        }
        .sidebar h2 {
            padding: 15px;
            height: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .menu-item {
            padding: 15px;
            background-color: #D0DFE9;
            color: black;
            text-decoration: none;
            display: flex;
            align-items: center;
            border-bottom: 1px solid white;
            transition: padding 0.3s ease;
        }
        .menu-item i {
            margin-right: 10px;
        }
        .menu-item span {
            display: inline;
        }
        .sidebar.shrink .menu-item {
            text-align: center;
            
        }
        .sidebar.shrink .menu-item span {
            display: none;
        }
        .sidebar.shrink .menu-item i {
            display: block;

            font-size: 24px;
        }
        .menu-item:hover, .active {
            background-color: #5E7D8D;
            color: white;
        }
        .logout {
            margin-top: auto;
            background-color: #D0DFE9;
            text-align: center;
        }
        .main-content {
            flex-grow: 1;
            display: flex;
            flex-direction: column;
            margin-left: 200px; /* Adjust for the width of the sidebar */
            transition: margin-left 0.3s ease;
        }
        .main-content.shrink {
            margin-left: 60px;
        }
        .topbar {
            width: calc(100% - 200px); /* Adjust for the width of the sidebar */
            height: 50px;
            background-color: #2C3E50;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
            color: white;
            position: fixed;
            top: 0;
            left: 200px; /* Adjust for the width of the sidebar */
            z-index: 1000;
            transition: left 0.3s ease, width 0.3s ease;
        }
        .topbar.shrink {
            left: 60px;
            width: calc(100% - 60px);
        }
        .content {
            flex-grow: 1;
            background-color: white;
            padding: 20px;
            margin-top: 50px; /* Adjust for the height of the topbar */
        }
        .user-icon {
            display: flex;
            align-items: center;
        }
        .user-icon span {
            margin-right: 10px;
        }
        .user-icon img {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background-color: #29A0B1;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        /* bars */
        .text-profile h1{
            font-size: 23px;
            font-weight: bold;
            margin-bottom: 10px;
            border-bottom: 2px solid #2C3E50;
            padding-bottom: 5px;
        }
        .contact-us {
            width: 100%;
            height:50%;
            display: flex;
            align-items: center;
            justify-content: space-around;
            padding: 100px 20px;
            color: black;

        }
        .contact-us ,.contact-us-middle{
            display: flex;
            align-items: center;
            font-style: bold;
        }
        .about-us{
            margin: 0 auto; 
            text-align: center;
            width: 70%;
            padding: 50px;
        }

    </style>
    <script>
        function toggleSidebar() {
            const sidebar = document.querySelector('.sidebar');
            const mainContent = document.querySelector('.main-content');
            const topbar = document.querySelector('.topbar');

            sidebar.classList.toggle('shrink');
            mainContent.classList.toggle('shrink');
            topbar.classList.toggle('shrink');
        }
    </script>
</head>
<body>
    <div class="sidebar">
        <h2>SCBS</h2>
        <a href="dashboard.php" class="menu-item"><i class="fas fa-tachometer-alt"></i> <span>DASHBOARD</span></a>
        <a href="transaction.php" class="menu-item"><i class="fas fa-exchange-alt"></i> <span>TRANSACTION</span></a>
        <a href="profile.php" class="menu-item"><i class="fas fa-user"></i><span>PROFILE</span></a>
        <a href="about.php" class="menu-item active"><i class="fas fa-info-circle"></i> <span>ABOUT</span></a>
        <a href="logout.php" class="menu-item logout"><i class="fas fa-sign-out-alt"></i> <span>LOG OUT</span></a>
    </div>
    <div class="main-content">
        <div class="topbar">
            <button onclick="toggleSidebar()">☰</button>
            <div class="user-icon">
                <span><?php echo htmlspecialchars($_SESSION['first_name']); ?></span>
                <img src="https://via.placeholder.com/30" alt="User Icon">
            </div>
        </div>
        <div class="content">
            <div class="text-profile">
                <h1>About SCBS</h1>
            </div>
            <div class="about-us">
            <p>Welcome to the Senior Citizen Booklet System, a platform designed to streamline and enhance services for our senior community. 
            Our mission is to provide an efficient, accessible, and user-friendly system that ensures senior citizens receive the benefits, privileges,
             and assistance they deserve.</p>
             <p>We understand the importance of making services more convenient for our elderly population. With this system, seniors can easily manage
                their booklets, access discounts, monitor benefits, and stay informed about government programs tailored to their needs.</p>
            <p>Our team is committed to innovation and inclusivity, ensuring that every senior citizen enjoys a hassle-free experience when using our system.
                 We believe in empowering our elderly with modern solutions while maintaining a sense of care, respect, and support for their well-being. 
                Join us in making senior citizen services more accessible and efficient. Together, we build a community that values and uplifts our seniors.</p>
            </div>
            <div class="text-profile">
                <h1>Contact Us</h1>
            </div>
                <div class="contact-us">
                    <span>
                        <b><i class="fas fa-map-marker-alt"></i>Address</b>
                        <p><br><br><b>NCR</b></p>
                        <p>8F AAP Tower, Aurora Blvd., New Manila, Quezon City</p>

                        <p><br><br><b>CENTRAL OFFICE</b></p>
                        <p>4F AAP Tower, Aurora Blvd., New Manila, Quezon City</p>
                    </span>

                    <span>
                        <b><i class="fas fa-envelope"></i></i>Email</b>
                        <p><br><br>For general concern</p>
                        <p>Click <u>scbc@gmail.com</u></p>
                        
                        <p><br><br>For Online Registration concern</p>
                        <p>Click <u>registration_scbs@gmail.com</u></p>
                    </span>
                    

                    <span>
                        <b><i class="fas fa-phone"></i>Phone</b>
                        <p><br><br><b>Click to call</b></p>
                        <p><b>the following landline nos.</b></p>

                        <p><br><br>+63 02 8652-5593 - NCR</p>
                        <p>+63 02 8652-4282 - Cluster 3</p>
                        <p>+63 02 8281-3301 - Central</p>
                    </span>
                </div>
        </div>
    </div>
</body>
</html>