<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SCBS Dashboard</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        /* bars */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        body {
            display: flex;
            height: 100%;
        }
        .sidebar {
            width: 200px;
            background-color: #2C3E50;
            color: white;
            display: flex;
            flex-direction: column;
            text-align: center;
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            transition: width 0.3s ease;
        }
        .sidebar.shrink {
            width: 60px;
        }
        .sidebar h2 {
            padding: 15px;
            height: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .menu-item {
            padding: 15px;
            background-color: #D0DFE9;
            color: black;
            text-decoration: none;
            display: flex;
            align-items: center;
            border-bottom: 1px solid white;
            transition: padding 0.3s ease;
        }
        .menu-item i {
            margin-right: 10px;
        }
        .menu-item span {
            display: inline;
        }
        .sidebar.shrink .menu-item {
            text-align: center;
            
        }
        .sidebar.shrink .menu-item span {
            display: none;
        }
        .sidebar.shrink .menu-item i {
            display: block;

            font-size: 24px;
        }
        .menu-item:hover, .active {
            background-color: #5E7D8D;
            color: white;
        }
        .logout {
            margin-top: auto;
            background-color: #D0DFE9;
            text-align: center;
        }
        .main-content {
            flex-grow: 1;
            display: flex;
            flex-direction: column;
            margin-left: 200px; /* Adjust for the width of the sidebar */
            transition: margin-left 0.3s ease;
        }
        .main-content.shrink {
            margin-left: 60px;
        }
        .topbar {
            width: calc(100% - 200px); /* Adjust for the width of the sidebar */
            height: 50px;
            background-color: #2C3E50;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
            color: white;
            position: fixed;
            top: 0;
            left: 200px; /* Adjust for the width of the sidebar */
            z-index: 1000;
            transition: left 0.3s ease, width 0.3s ease;
        }
        .topbar.shrink {
            left: 60px;
            width: calc(100% - 60px);
        }
        .content {
            flex-grow: 1;
            background-color: white;
            padding: 20px;
            margin-top: 50px; /* Adjust for the height of the topbar */
        }
        .user-icon {
            display: flex;
            align-items: center;
        }
        .user-icon span {
            margin-right: 10px;
        }
        .user-icon img {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background-color: #29A0B1;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        /* bars */
        .dashboard {
            width: 90%;
            margin: 20px auto;
            display: grid;
            grid-template-columns: repeat(3, 1fr);
            gap: 20px;
        }

        .card {
            background-color: #7d8c93;
            color: white;
            border-radius: 5px;
            text-align: center;
            padding: 20px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .table-container {
            margin-top: 30px;
            width: 100%;
        }

        .tabs {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }

        .tab {
            cursor: pointer;
            padding: 10px 20px;
            margin: 0 5px;
            background-color: #7d8c93;
            color: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .tab.active {
            background-color: #5b2c6f;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .table th, .table td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
        }

        .table th {
            background-color: #5b2c6f;
            color: white;
        }

        .hidden {
            display: none;
        }

        .image-container {
            display: flex;
            justify-content: center;
            align-items: center;
            margin: 20px 0;
        }
        .text-profile h1{
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 10px;
            border-bottom: 2px solid #2C3E50;
            padding-bottom: 5px;
        }
    </style>
    <script>
        function showTable(tab) {

            const tabs = document.querySelectorAll('.tab');
            tabs.forEach(t => t.classList.remove('active'));
            document.querySelector(`[data-tab="${tab}"]`).classList.add('active');
        }

        function toggleSidebar() {
            const sidebar = document.querySelector('.sidebar');
            const mainContent = document.querySelector('.main-content');
            const topbar = document.querySelector('.topbar');

            sidebar.classList.toggle('shrink');
            mainContent.classList.toggle('shrink');
            topbar.classList.toggle('shrink');
        }
    </script>
</head>
<body>
    <div class="sidebar">
        <h2>SCBS</h2>
        <a href="dashboard.php" class="menu-item"><i class="fas fa-tachometer-alt"></i> <span>DASHBOARD</span></a>
        <a href="transaction.php" class="menu-item active"><i class="fas fa-exchange-alt"></i> <span>TRANSACTION</span></a>
        <a href="qrcam.php" class="menu-item"><i class="fas fa-qrcode"></i> <span>SCAN QR</span></a>
		<a href="list.php" class="menu-item"><i class="fas fa-qrcode"></i> <span>CITIZEN LIST</span></a>
        <a href="index.php" class="menu-item logout"><i class="fas fa-sign-out-alt"></i> <span>LOG OUT</span></a>
    </div>
    <div class="main-content">
        <div class="topbar">
            <button onclick="toggleSidebar()">☰</button>
            <div class="user-icon">
                <span>Merchant Name</span>
                <img src="https://via.placeholder.com/30" alt="User Icon">
            </div>
        </div>
        <div class="content">
       
            <!-- Main content goes here -->
        </div>
	</div>
</body>
</html>
