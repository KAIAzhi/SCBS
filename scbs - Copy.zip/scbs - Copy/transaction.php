<?php
	require 'connection.php';
	include 'process.transact.php';
    
    session_start();
    if (!isset($_SESSION['first_name'])) {
        header("Location: index.php");
    }
$transactionList = getTransactionList($conn);
$transactionItemList = getTransactionItemList($conn);
$grandTotal = 0;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SCBS Transaction</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">
    <style>
        /* bars */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        body {
            height: 100%;
        }
        .sidebar {
            width: 200px;
            background-color: #2C3E50;
            color: white;
            display: flex;
            flex-direction: column;
            text-align: center;
            position: fixed;
            top: 0;
            left: 0;
            height: 100%;
            transition: width 0.3s ease;
        }
        .sidebar.shrink {
            width: 60px;
        }
        .sidebar h2 {
            padding: 15px;
            height: 50px;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .menu-item {
            padding: 15px;
            background-color: #D0DFE9;
            color: black;
            text-decoration: none;
            display: flex;
            align-items: center;
            border-bottom: 1px solid white;
            transition: padding 0.3s ease;
        }
        .menu-item i {
            margin-right: 10px;
        }
        .menu-item span {
            display: inline;
        }
        .sidebar.shrink .menu-item {
            text-align: center;
            
        }
        .sidebar.shrink .menu-item span {
            display: none;
        }
        .sidebar.shrink .menu-item i {
            display: block;

            font-size: 24px;
        }
        .menu-item:hover, .active {
            background-color: #5E7D8D;
            color: white;
        }
        .logout {
            margin-top: auto;
            background-color: #D0DFE9;
            text-align: center;
        }
        .main-content {
            flex-grow: 1;
            display: flex;
            flex-direction: column;
            margin-left: 200px; /* Adjust for the width of the sidebar */
            transition: margin-left 0.3s ease;
        }
        .main-content.shrink {
            margin-left: 60px;
        }
        .topbar {
            width: calc(100% - 200px); /* Adjust for the width of the sidebar */
            height: 50px;
            background-color: #2C3E50;
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 0 20px;
            color: white;
            position: fixed;
            top: 0;
            left: 200px; /* Adjust for the width of the sidebar */
            z-index: 1000;
            transition: left 0.3s ease, width 0.3s ease;
        }
        .topbar.shrink {
            left: 60px;
            width: calc(100% - 60px);
        }
        .content {
            flex-grow: 1;
            background-color: white;
            padding: 20px;
            margin-top: 50px; /* Adjust for the height of the topbar */
        }
        .user-icon {
            display: flex;
            align-items: center;
        }
        .user-icon span {
            margin-right: 10px;
        }
        .user-icon img {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            background-color: #29A0B1;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        /* bars */
        .table-container {
            margin-top: 30px;
            width: 100%;
        }

        .tabs {
            display: flex;
            justify-content: center;
            margin-bottom: 20px;
        }

        .tab {
            cursor: pointer;
            padding: 10px 20px;
            margin: 0 5px;
            background-color: #7d8c93;
            color: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .tab.active {
            background-color: #5b2c6f;
        }

        .table {
            width: 100%;
            border-collapse: collapse;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        .table th, .table td {
            border: 1px solid #ccc;
            padding: 10px;
            text-align: left;
        }

        .table th {
            background-color: #5b2c6f;
            color: white;
        }

        .hidden {
            display: none;
        }



        /* MODAL CSS */
        .modal {
            display: none; /* Hidden by default */
            position: fixed; /* Stay in place */
            z-index: 1; /* Sit on top */
            padding-top: 100px; /* Location of the box */
            left: 0;
            top: 0;
            width: 100%; /* Full width */
            height: 100%; /* Full height */
            overflow: auto; /* Enable scroll if needed */
            background-color: rgb(0,0,0); /* Fallback color */
            background-color: rgba(0,0,0,0.4); /* Black w/ opacity */
            }

            /* Modal Content */
            .modal-content {
            background-color: #fefefe;
            margin: auto;
            padding: 20px;
            border: 1px solid #888;
            width: 80%;
        }

            /* The Close Button */
            .close {
            color: #aaaaaa;
            float: right;
            font-size: 28px;
            font-weight: bold;
        }

            .close:hover,
            .close:focus {
            color: #000;
            text-decoration: none;
            cursor: pointer;
        }

        .center {
            text-align: center;
            }

            .pagination {
            display: inline-block;
            }

            .pagination a {
            color: black;
            float: left;
            padding: 8px 16px;
            text-decoration: none;
            transition: background-color .3s;
            border: 1px solid #ddd;
            margin: 0 4px;
            margin-top: 15px;
            }

            .pagination a.active {
            background-color: #4CAF50;
            color: white;
            border: 1px solid #4CAF50;
        }

            .pagination a:hover:not(.active) {background-color: #ddd;
        }
        tr:hover {
            background-color: #D0DFE9;
            }

            .search-container {
                display: flex;
                justify-content: flex-end; /* Aligns search bar to the right */
                margin-bottom: 10px; /* Space between search bar and table */
            }

            #search-bar {
                width: 300px;
                padding: 10px;
                margin: 10px 0;
                border: 2px solid #ccc;
                border-radius: 5px;
                font-size: 16px;
                outline: none;
                height: 30px;
            }

        #search-bar:focus {
                border-color: #007bff; 
                box-shadow: 0 0 5px rgba(16, 17, 18, 0.5);
            }

                .sort-icon {
                    font-size: 12px;
                    margin-left: 5px;
                    color: #ccc;
                    margin-left: 15px;
                }

                .sorted-asc .sort-icon {
                    color: ;
                }
                .sorted-asc .sort-icon::after {
                    content: " ▲";
                }

                .sorted-desc .sort-icon {
                    color: white;
                }
                .sorted-desc .sort-icon::after {
                    content: " ▼";
                }
    </style>
    
     <script>
        let currentPage = 1;
        const rowsPerPage = 5; // Adjust as needed

        function showTable(tab) {
            document.querySelectorAll('.data-table').forEach(table => table.classList.add('hidden'));
            document.getElementById(tab).classList.remove('hidden');
            document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
            document.querySelector(`[data-tab="${tab}"]`).classList.add('active');
            currentPage = 1; // Reset to first page when switching tables
            updateTable(tab);
        }

        function updateTable(tab) {
            const table = document.getElementById(tab);
            const rows = table.querySelectorAll("tbody tr");
            const totalPages = Math.ceil(rows.length / rowsPerPage);
            
            rows.forEach((row, index) => {
                row.style.display = (index >= (currentPage - 1) * rowsPerPage && index < currentPage * rowsPerPage) ? "" : "none";
            });
            updatePagination(tab, totalPages);
        }

        function updatePagination(tab, totalPages) {
            const paginationContainer = document.querySelector(".pagination");
            paginationContainer.innerHTML = '';
            
            if (totalPages > 1) {
                let paginationHTML = `<a href="#" onclick="changePage('${tab}', ${currentPage - 1})">&laquo;</a>`;
                for (let i = 1; i <= totalPages; i++) {
                    paginationHTML += `<a href="#" class="${i === currentPage ? 'active' : ''}" onclick="changePage('${tab}', ${i})">${i}</a>`;
                }
                paginationHTML += `<a href="#" onclick="changePage('${tab}', ${currentPage + 1})">&raquo;</a>`;
                paginationContainer.innerHTML = paginationHTML;
            }
        }

        function changePage(tab, page) {
            const rows = document.getElementById(tab).querySelectorAll("tbody tr");
            const totalPages = Math.ceil(rows.length / rowsPerPage);
            if (page < 1 || page > totalPages) return;
            currentPage = page;
            updateTable(tab);
        }

        document.addEventListener("DOMContentLoaded", function () {
            showTable('medicine-table');
        });

        function sortTable(tab, columnIndex) {
    const table = document.getElementById(tab);
    const tbody = table.querySelector("tbody");
    const rows = Array.from(tbody.querySelectorAll("tr"));
    const headers = table.querySelectorAll("th");

    let isAscending = tbody.dataset.sortOrder !== 'asc';
    tbody.dataset.sortOrder = isAscending ? 'asc' : 'desc';

    rows.sort((a, b) => {
        const cellA = a.cells[columnIndex].innerText.trim();
        const cellB = b.cells[columnIndex].innerText.trim();

        return isNaN(cellA) || isNaN(cellB) 
            ? (isAscending ? cellA.localeCompare(cellB) : cellB.localeCompare(cellA))
            : (isAscending ? cellA - cellB : cellB - cellA);
    });

    tbody.innerHTML = "";
    rows.forEach(row => tbody.appendChild(row));

    headers.forEach(header => header.classList.remove("sorted-asc", "sorted-desc"));
    headers[columnIndex].classList.add(isAscending ? "sorted-asc" : "sorted-desc");
}
        
        document.addEventListener("DOMContentLoaded", function () {
            showTable('medicine-table');
        });

    </script>
</head>
<body>
    <div class="sidebar">
        <h2>SCBS</h2>
        <a href="dashboard.php" class="menu-item "><i class="fas fa-tachometer-alt"></i> <span>DASHBOARD</span></a>
        <a href="transaction.php" class="menu-item active"><i class="fas fa-exchange-alt"></i> <span>TRANSACTION</span></a>
        <a href="profile.php" class="menu-item"><i class="fas fa-user"></i><span>PROFILE</span></a>
        <a href="about.php" class="menu-item"><i class="fas fa-info-circle"></i> <span>ABOUT</span></a>
        <a href="logout.php" class="menu-item logout"><i class="fas fa-sign-out-alt"></i> <span>LOG OUT</span></a>
    </div>
    <div class="main-content">
        <div class="topbar">
            <button onclick="toggleSidebar()">☰</button>
            <div class="user-icon">
                <span><?php echo htmlspecialchars($_SESSION['first_name']); ?></span>
                <img src="https://via.placeholder.com/30" alt="User Icon">
            </div>
        </div>
        <div class="content">
			
		<form method="POST" action = "generatePDF.php">
			<input type="submit" value = "Genarate PDF">
        </form>
			
            <!-- Main content goes here -->
            <div class="table-container">
                <div class="tabs">
                    <div class="tab active" data-tab="medicine-table" onclick="showTable('medicine-table')">MEDICINE</div>
                    <div class="tab" data-tab="groceries-table" onclick="showTable('groceries-table')">GROCERIES</div>
                </div>

                <div class="search-container">
    	<input type="text" id="search-bar" placeholder="Search...">
</div>

                <!-- medicine -->
                <div id="medicine-table" class="data-table">
            <table class="table">
                <thead>
                    <tr>
                        <th onclick="sortTable('medicine-table', 0)">Transaction ID <span class="sort-icon"></span></th>
                        <th onclick="sortTable('medicine-table', 1)">Date & Time <span class="sort-icon"></span></th>
                        <th onclick="sortTable('medicine-table', 2)">Store/Service <span class="sort-icon"></span></th>
                        <th onclick="sortTable('medicine-table', 3)">Item/Service <span class="sort-icon"></span></th>
                        <th onclick="sortTable('medicine-table', 4)">Amount <span class="sort-icon"></span></th>
                        <th onclick="sortTable('medicine-table', 5)">Discount <span class="sort-icon"></span></th>
                        <th onclick="sortTable('medicine-table', 6)">Total Payable <span class="sort-icon"></span></th>
                    </tr>
                </thead>
				
				
				
				
                <tbody data-sort-order="asc">
					<?php
						foreach ($transactionList as $seniorCitizen) {
						  ?>
                        <tr id="myBtn">
                            <td><?php echo $seniorCitizen['tr_id']; ?></td>
							<td><?php echo $seniorCitizen['tr_date']; ?></td>
							<td><?php echo $seniorCitizen['store']; ?></td>
							<td><?php echo $seniorCitizen['service']; ?></td>
							<td><?php echo $seniorCitizen['tr_amount']; ?></td>
							<td><?php echo $seniorCitizen['discount']; ?></td>
							<td><?php echo $seniorCitizen['total']; ?></td>
                        </tr>
					<?php
						}
       				 ?>
                </tbody>
            </table>
        </div>
				
				

                <!-- grocery -->
                <div id="groceries-table" class="data-table hidden">
            <table class="table">
                <thead>
                    <tr>
                        <th onclick="sortTable('groceries-table', 0)">Date & Time <span class="sort-icon"></span></th>
                        <th onclick="sortTable('groceries-table', 1)">Store/Service <span class="sort-icon"></span></th>
                        <th onclick="sortTable('groceries-table', 2)">Item/Service <span class="sort-icon"></span></th>
                        <th onclick="sortTable('groceries-table', 3)">Amount <span class="sort-icon"></span></th>
                        <th onclick="sortTable('groceries-table', 4)">Discount <span class="sort-icon"></span></th>
                        <th onclick="sortTable('groceries-table', 5)">Total Payable <span class="sort-icon"></span></th>
                    </tr>
                </thead>
                <tbody data-sort-order="asc">
                        <tr>
                            <td>2025-02-11 2:00 PM</td>
                            <td>SuperMart</td>
                            <td>Fruits</td>
                            <td>₱1,000</td>
                            <td>10% (₱100)</td>
                            <td>₱900</td>
                        </tr>
                        <tr>
                            <td>2025-02-12 3:00 PM</td>
                            <td>GrocerEase</td>
                            <td>Vegetables</td>
                            <td>₱800</td>
                            <td>15% (₱120)</td>
                            <td>₱680</td>
                        </tr>
                        <tr>
                            <td>2025-07-12 9:00 PM</td>
                            <td>Puregold</td>
                            <td>Vegetables</td>
                            <td>₱500</td>
                            <td>10% (₱120)</td>
                            <td>₱790</td>
                        </tr>
                        <tr>
                            <td>2025-03-16 7:00 PM</td>
                            <td>GrocerEase</td>
                            <td>Fruits</td>
                            <td>₱899</td>
                            <td>18% (₱120)</td>
                            <td>₱670</td>
                        </tr>
                        <tr>
                            <td>2025-08-15 10:00 AM</td>
                            <td>Lopues East</td>
                            <td>Ingredients</td>
                            <td>₱800</td>
                            <td>10% (₱120)</td>
                            <td>₱680</td>
                        </tr>
                        <tr>
                            <td>2025-08-15 3:00 PM</td>
                            <td>SaveMore</td>
                            <td>Fish</td>
                            <td>₱450</td>
                            <td>10% (₱45)</td>
                            <td>₱405</td>
                        </tr>
                     </tbody>
            </table>
        </div>

        </div>

        
        <!-- The Modal -->
        <div id="myModal" class="modal">
        
          <!-- Modal content -->
          <div class="modal-content">
            <span class="close">&times;</span>
            <table class="table">
                <tr>
                    <th>Under Commodities</th>
                    <th>Qty</th>
                    <th>Amount of Purchase</th>
                </tr>

                <?php
					foreach ($transactionItemList as $orderItems) {
                        $partial = $orderItems['quantity'] * $orderItems['price'];
                        $grandTotal += $partial;
					?>
                    <tr id="myBtn">
                        <td><?php echo $orderItems['itemname']; ?></td>
                        <td><?php echo $orderItems['quantity']; ?></td>
                        <td><?php echo $orderItems['price']; ?></td>
                    </tr>

					<?php
						}
       				 ?>

                    <tr>
                        <th><h2>TOTAL AMOUNT</h2></th>
                        <td></td>
                        <td><h3><strong><?php echo number_format($grandTotal, 2); ?></strong></h3></td>
                    </tr>
            </table>
          </div>
        
        </div>


        <div class="center">
                    <div class="pagination"></div>
                </div>
        
        <script>
        // Get the modal
        var modal = document.getElementById("myModal");
        
        // Get the button that opens the modal
        var btn = document.getElementById("myBtn");
        
        // Get the <span> element that closes the modal
        var span = document.getElementsByClassName("close")[0];
        
        // When the user clicks the button, open the modal 
        btn.onclick = function() {
          modal.style.display = "block";
        }
        
        // When the user clicks on <span> (x), close the modal
        span.onclick = function() {
          modal.style.display = "none";
        }
        
        // When the user clicks anywhere outside of the modal, close it
        window.onclick = function(event) {
          if (event.target == modal) {
            modal.style.display = "none";
          }
        }
        </script>
            <!-- Main content goes here -->
        </div>
    </div>
</body>
</html>
